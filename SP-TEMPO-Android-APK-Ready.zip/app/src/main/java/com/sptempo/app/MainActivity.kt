package com.sptempo.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import android.net.Uri

class MainActivity : AppCompatActivity() {
    private val startUrl = "https://tempo-freight-5buehe.v2.appdeploy.ai/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CustomTabsIntent.Builder().build().launchUrl(this, Uri.parse(startUrl))
    }
}
