plugins {
    id("com.android.application")
    kotlin("android")
}
android {
    namespace = "com.sptempo.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.sptempo.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
dependencies {
    implementation("androidx.browser:browser:1.8.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
