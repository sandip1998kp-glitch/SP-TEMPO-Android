# SP TEMPO — Android APK-ready project

This project packages the live SP TEMPO app URL as an Android launcher app.

Live app:
https://tempo-freight-5buehe.v2.appdeploy.ai/

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Generate App Bundles or APKs > Generate APKs.
4. For a release APK, configure a signing key under Android Studio's Generate Signed Bundle/APK wizard.

## Important
This is an APK-ready launcher project. It does not claim to contain a precompiled APK.
For production-grade Trusted Web Activity behavior, configure Digital Asset Links for the SP TEMPO domain and use the TWA/Bubblewrap flow.
